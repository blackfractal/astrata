import fs from 'node:fs';import zlib from 'node:zlib';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {Game} from './src/engine.mjs';
const root=new URL('./',import.meta.url),read=n=>JSON.parse(fs.readFileSync(new URL(n,root),'utf8'));
const ev=zlib.gunzipSync(fs.readFileSync(new URL('original-events.jsonl.gz',root))).toString('utf8').trim().split('\n').map(x=>JSON.parse(x));
const split=read('tavern-event.json').index;
const human=[];const resumes=[];for(const [i,e] of ev.slice(0,split+1).entries()){if(e.kind==='resume'){resumes.push({event:i,keptSteps:e.state.steps,discardedAttemptActions:human.length-e.state.steps});human.length=e.state.steps;}if(e.kind==='decision'&&e.action){assert.equal(e.state.steps,human.length+1);human.push({key:e.action.key,label:e.action.label,origin:'Jonathan'});}}
const prefix=read('prepared-hart-prefix.json').map(x=>({...x,origin:'Tavern continuation'}));
const boss=read('prepared-hart-beam-win.json');const loom=read('loom-guided-win.json');
const trace=[...human,...prefix,...boss.trace.map(x=>({...x,origin:'Hart search'})),...loom.trace.map(x=>({...x,origin:'Loom continuation'}))];
const g=new Game(303001354), milestones=[];const record=[];let lastMode=g.s.mode;
for(let i=0;i<trace.length;i++){
 const row=trace[i],a=g.legal().find(x=>x.key===row.key);assert.ok(a,'Illegal action '+i+' '+row.label);
 record.push({...row,label:a.label,hpBefore:g.s.hp,modeBefore:g.s.mode,stratum:g.s.stratum,round:g.s.field.round,turn:g.s.battle?.turn});g.act(a);
 if(i===human.length-1){const archived=ev[split].state;for(const k of ['hp','gold','rng','deck','inventory','equipment','field'])assert.deepEqual(g.s[k],archived[k],'human prefix '+k);}
 if(g.s.mode==='battle'&&lastMode!=='battle')milestones.push({step:i,type:'battle',hp:g.s.hp,stratum:g.s.stratum,enemies:g.s.battle.enemies.map(e=>e.name)});
 if(g.s.mode==='tavern'&&lastMode!=='tavern')milestones.push({step:i,type:'tavern',hp:g.s.hp,gold:g.s.gold,stratum:g.s.stratum});lastMode=g.s.mode;
 if(i===human.length+prefix.length-1)for(const k of ['hp','rng','deck','inventory','equipment','field'])assert.deepEqual(g.s[k],read('prepared-hart-start.json')[k],'Hart start '+k);
}
assert.equal(g.s.mode,'result');assert.equal(g.s.outcome,'win');assert.equal(g.s.stratum,2);assert.equal(g.s.hp,51);
for(const k of ['hp','gold','rng','deck','equipment','inventory'])assert.deepEqual(g.s[k],loom.final[k],'final '+k);
const sources=Object.fromEntries(fs.readdirSync(new URL('src/',root)).filter(n=>n.endsWith('.mjs')).map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(new URL('src/'+n,root))).digest('hex')]));
const report={seed:303001354,package:'2.1.13',versions:g.s.version,actions:trace.length,unchangedHumanActions:human.length,sourceEventIndex:split,firstChangedAction:prefix[0].label,retainedHumanResumes:resumes,result:g.s.outcome,stratum:g.s.stratum,hp:g.s.hp,encounters:g.s.stats.encounters,milestones,sourceHashes:sources};
fs.writeFileSync(new URL('verification.json',root),JSON.stringify(report,null,2));fs.writeFileSync(new URL('verified-winning-line.json',root),JSON.stringify({trace:record,final:g.s}));console.log(JSON.stringify({...report,sourceHashes:undefined,milestones:undefined},null,2));
