import fs from 'node:fs';import {Game,adjacent,offense} from './src/engine.mjs';import {WeightedPolicy} from './src/policy.mjs';import {cards,items} from './src/content.mjs';
const baseName=process.argv[2]||'tavern',limit=+(process.argv[3]||60),offset=+(process.argv[4]||0),base=JSON.parse(fs.readFileSync(new URL('./'+baseName+'-start.json',import.meta.url)));let best=-Infinity;const results=[];base.history=[];base.log=[];
for(let trial=offset;trial<offset+limit;trial++){
 const weights={damage:[.7,1.5,3,5][trial%4],survival:[2,4,8][Math.floor(trial/4)%3],economy:4,development:1,progress:1};const g=new Game(0,structuredClone(base)),p=new WeightedPolicy(weights),trace=[];let rs=trial+500;const random=()=>{rs=(Math.imul(rs,1664525)+1013904223)>>>0;return rs/4294967296;};
 const act=a=>{if(!a)throw Error('missing action');trace.push({key:a.key,label:a.label,stratum:g.s.stratum,mode:g.s.mode,round:g.s.field.round,turn:g.s.battle?.turn,hp:g.s.hp});g.act(a);};
 if(baseName==='tavern'){
 const find=(type,pred=()=>true)=>g.legal().find(a=>a.type===type&&pred(a));const buy=id=>act(find('buy',a=>a.effects.item===id));const equip=(id,slot)=>act(find('equip',a=>a.item===g.s.inventory.find(x=>x.id===id).uid&&a.slot===slot));const socket=(id,gem)=>act(find('socket',a=>a.uid===g.s.inventory.find(x=>x.id===id).uid&&a.gem===g.s.inventory.find(x=>x.id===gem).uid));
 act(find('heal'));buy('focusRing');equip('focusRing','finger1');socket('focusRing','channelGem');buy('stoneArmor');equip('stoneArmor','torso');
 if(trial%3===0){act(find('unsocket'));buy('sapphire');socket('bronze','sapphire');}
 if(trial%3===1){socket('ring','insightGem');}
 if(trial%3===2){act(find('sell',a=>a.uid===g.s.inventory.find(x=>x.id==='ruby').uid));act(find('unsocket'));act(find('sell',a=>a.uid===g.s.inventory.find(x=>x.id==='emerald').uid));buy('sapphire');socket('bronze','sapphire');socket('ring','insightGem');}
 act(find('leave'));
 }
 const score=p.score.bind(p);p.score=(o,a)=>{let [v,w]=score(o,a);const b=o.battle,f=a.effects;
 if(a.type==='heal')v+=1000;
 if(a.type==='eventChoice'&&(a.tradeItem!=null||a.tradeCard!=null))v-=25;
 if(a.type==='place'){
  const ns=adjacent(a.slot).map(i=>b.grid[i].at(-1)).filter(Boolean);if(ns.some(c=>cards[c.id].condition==='isolated'))v-=30;
  v+=(a.slot%7)*.5;
  if(b.enemies.some(e=>e.id==='hart'))v-=b.grid.filter((x,i)=>Math.floor(i/7)===Math.floor(a.slot/7)&&x.length).length*(trial%4);
 }
 if(a.type==='activate'&&f.hpDamage)v+=offense(b.grid[a.slot].at(-1).hp,a.element,b.enemies.find(e=>e.uid===a.target)?.element)*weights.damage;
 if(a.type==='activate'&&f.ward)v+=Math.min(f.ward,25)*weights.survival/2;
 if(a.type==='activate'&&(f.insight||f.adjInsight))v+=(f.insight||f.adjInsight||0)*2;
 if(a.type==='buy'&&!f.item?.startsWith('card:')){const d=items[f.item];if(d?.effect?.block||d?.effect?.armor)v+=15;}
 if(a.type==='recall'&&f.spent)v+=trial%3===0?20:0;
 v+=(random()-.5)*(trial<12?0:trial<80?3:8);return [v,w];};
 for(let step=0;step<(baseName==='hart'?500:2800)&&g.s.mode!=='result';step++){
  const a=p.choose(g.observe(),g.legal())?.action;if(!a)break;act(a);
  if(baseName==='hart'&&g.s.mode==='reward')break;
 }
 const s=g.s,win=s.mode==='result'&&s.outcome==='win'&&s.stratum===2;const r={trial,weights,win,hp:s.hp,stratum:s.stratum,round:s.field.round,mode:s.mode,cause:s.cause,lastFight:s.stats.encounters.at(-1),steps:trace.length};results.push(r);
 const value=win?100000:s.stratum*10000+s.field.round*100+(s.battle?s.battle.enemies.reduce((n,e)=>n+e.maxHp-e.hp,0):0);
 if(value>best||win){best=value;console.log(JSON.stringify(r));fs.writeFileSync(new URL('./'+baseName+'-best-'+offset+'.json',import.meta.url),JSON.stringify({result:r,trace,final:s}));}
 if(win || (baseName==='hart'&&s.mode==='reward')){fs.writeFileSync(new URL('./'+baseName+'-win.json',import.meta.url),JSON.stringify({result:r,trace,final:s}));break;}
 if(trial%10===9)console.log('Trials '+(trial+1));
}
fs.writeFileSync(new URL('./'+baseName+'-summary-'+offset+'.json',import.meta.url),JSON.stringify(results,null,2));
