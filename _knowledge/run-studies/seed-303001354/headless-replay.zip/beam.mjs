import fs from 'node:fs';import {Game,adjacent,offense} from './src/engine.mjs';import {WeightedPolicy} from './src/policy.mjs';import {cards,items} from './src/content.mjs';
const baseName=process.argv[2]||'prepared-hart', beamWidth=+(process.argv[3]||16), variants=+(process.argv[4]||24);
const base=JSON.parse(fs.readFileSync(new URL('./'+baseName+'-start.json',import.meta.url)));base.history||=[];base.log||=[];
let beam=[{state:base,trace:[]}], win=null;
for(let depth=0;depth<22&&!win;depth++){
 const candidates=[];
 for(let ni=0;ni<beam.length&&!win;ni++)for(let vno=0;vno<variants&&!win;vno++){
  const node=beam[ni],trial=depth*1000+ni*variants+vno+100;
  const weights={damage:[.7,1.5,3,5][trial%4],survival:[2,4,8][Math.floor(trial/4)%3],economy:4,development:1,progress:1};
  const g=new Game(0,structuredClone(node.state)),p=new WeightedPolicy(weights),trace=[...node.trace];let rs=trial+500;const random=()=>{rs=(Math.imul(rs,1664525)+1013904223)>>>0;return rs/4294967296;};
const score=p.score.bind(p);p.score=(o,a)=>{let [v,w]=score(o,a);const b=o.battle,f=a.effects;
 if(a.type==='heal')v+=1000;
 if(a.type==='eventChoice'&&(a.tradeItem!=null||a.tradeCard!=null))v-=25;
 if(a.type==='place'){
  const ns=adjacent(a.slot).map(i=>b.grid[i].at(-1)).filter(Boolean);if(ns.some(c=>cards[c.id].condition==='isolated'))v-=30;
  v+=(a.slot%7)*.5;
  if(b.enemies.some(e=>e.id==='hart'))v-=b.grid.filter((x,i)=>Math.floor(i/7)===Math.floor(a.slot/7)&&x.length).length*(trial%4);
 }
 if(a.type==='place' && b){
 const def=cards[f.card], ns=adjacent(a.slot).map(i=>b.grid[i].at(-1)).filter(Boolean);
 if(def.effects.adjHeal)v+=ns.length*3;
 if(def.attune)for(const n of ns)if(b.enemies.some(e=>offense(4,n.element,e.element)>4))v+=4;
 if(def.effects.damage && def.element!=='Arcane')for(const n of ns)if(cards[n.id].attune && n.used<cards[n.id].limit)v+=3;
 if(b.telegraphs?.some(t=>t.spaces?.includes(a.slot)||t.targets?.includes(a.slot)))v-=60;
}
if(a.type==='recall' && b){
 const c=b.grid[a.slot].at(-1),d=cards[c.id];
 if(b.telegraphs?.some(t=>t.spaces?.includes(a.slot)||t.targets?.includes(a.slot)))v+=45;
 if(f.spent && ['water','solitude','conduit','clear'].includes(c.id))v+=22;
}
if(a.type==='activate'&&f.transmute){
 const c=b.grid[a.cardTarget].at(-1),d=cards[c.id],uses=Math.max(0,d.limit-c.used);
 const basePower=d.effects.hpDamage?c.hp:(d.effects.damage||0);
 const gain=b.enemies.reduce((n,e)=>Math.max(n,offense(basePower,a.newElement,e.element)-offense(basePower,c.element,e.element)),0);
 v+=gain*Math.min(2,uses)*1.5;
 const relays=adjacent(a.cardTarget).filter(i=>{const x=b.grid[i].at(-1);return x&&cards[x.id].attune&&x.used<cards[x.id].limit;}).length;
 if(b.enemies.some(e=>offense(4,a.newElement,e.element)>4))v+=relays*4;
}
if(a.type==='activate'&&f.adjHeal)v+=adjacent(a.slot).filter(i=>b.grid[i].length).length*f.adjHeal*weights.survival;
if(a.type==='activate'&&f.hpDamage)v+=offense(b.grid[a.slot].at(-1).hp,a.element,b.enemies.find(e=>e.uid===a.target)?.element)*weights.damage;
 if(a.type==='activate'&&f.ward)v+=Math.min(f.ward,25)*weights.survival/2;
 if(a.type==='activate'&&(f.insight||f.adjInsight))v+=(f.insight||f.adjInsight||0)*2;
 if(a.type==='buy'&&!f.item?.startsWith('card:')){const d=items[f.item];if(d?.effect?.block||d?.effect?.armor)v+=15;}
 if(a.type==='recall'&&f.spent)v+=trial%3===0?20:0;
 v+=(random()-.5)*(8+(trial%4)*5);return [v,w];};

  const initialTurn=g.s.battle.turn;
  for(let step=0;step<90&&g.s.mode==='battle'&&g.s.battle.turn===initialTurn;step++){
   const a=p.choose(g.observe(),g.legal())?.action;if(!a)break;
   trace.push({key:a.key,label:a.label,turn:g.s.battle.turn,hp:g.s.hp});g.act(a);
  }
  if(g.s.mode==='reward'){win={trace,final:g.s};break;}
  if(g.s.mode!=='battle'||g.s.hp<=0)continue;
  const b=g.s.battle,left=b.enemies.reduce((n,e)=>n+Math.max(0,e.hp),0);
  const board=b.grid.flat().reduce((n,c)=>n+Math.max(0,c.hp||0)*.12+Math.max(0,(cards[c.id].limit||0)-c.used)*.3,0);
  const value=g.s.hp*1.6-left+board+(b.permanent.focus||0)*5-(g.s.status.burn||0)*3;
  candidates.push({state:g.s,trace,value});
 }
 candidates.sort((a,b)=>b.value-a.value);const seen=new Set();beam=[];
 for(const c of candidates){const key=JSON.stringify([c.state.hp,c.state.battle.enemies.map(e=>e.hp),c.state.battle.grid,c.state.battle.discard.map(c=>c.uid)]);if(seen.has(key))continue;seen.add(key);beam.push(c);if(beam.length>=beamWidth)break;}
 console.log(JSON.stringify({depth,candidates:candidates.length,best:beam[0]&&{hp:beam[0].state.hp,enemy:beam[0].state.battle.enemies.map(e=>e.hp),turn:beam[0].state.battle.turn},win:!!win}));
 if(!beam.length&&!win)break;
}
if(win){fs.writeFileSync(new URL('./'+baseName+'-beam-win.json',import.meta.url),JSON.stringify(win));console.log('WIN HP '+win.final.hp+' actions '+win.trace.length);}
else if(beam[0])fs.writeFileSync(new URL('./'+baseName+'-beam-best.json',import.meta.url),JSON.stringify(beam[0]));
