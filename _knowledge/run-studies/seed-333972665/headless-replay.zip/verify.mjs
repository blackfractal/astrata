import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {Game} from './src/engine.mjs';
const root=new URL('./',import.meta.url),read=n=>JSON.parse(fs.readFileSync(new URL(n,root),'utf8'));
const ev=read('events.json');const win=read('kill-beam-win.json');const prefix=read('kill-prefix.json');
const human=ev.slice(1,109).filter(e=>e.kind==='decision').map(e=>e.action);
const trace=[...human,...prefix,...win.trace];const g=new Game(333972665),record=[];let checked=false;
for(let i=0;i<trace.length;i++){
 const a=g.legal().find(a=>a.key===trace[i].key);assert.ok(a,`Illegal action ${i}: ${trace[i].label}`);
 record.push({key:a.key,label:a.label,turn:g.s.battle?.turn,hp:g.s.hp});g.act(a);
 if(i===human.length-1){for(const k of ['hp','rng','deck','inventory','equipment','field','battle'])assert.deepEqual(g.s[k],ev[108].state[k],k);checked=true;}
}
assert.ok(checked);assert.equal(g.s.mode,'reward');assert.equal(g.s.hp,10);assert.equal(g.s.battle.turn,6);assert.ok(g.s.battle.enemies.every(e=>e.hp<=0));
const build=JSON.parse(fs.readFileSync(process.env.APPDATA+'/astrata/builds/'+ev[0].version.id+'.json','utf8'));
console.log('buildsourcekeys',Object.keys(build.sources));
const comparison=[];for(const [name,source] of Object.entries(build.sources)){
 const file=name.startsWith('src/')?name:'src/'+name;const p=new URL(file,root);
 if(!fs.existsSync(p))throw Error('Missing '+file);
 const actual=fs.readFileSync(p,'utf8');const original=typeof source==='string'?source:source.content;
 assert.equal(actual.replace(/\r\n/g,'\n'),original.replace(/\r\n/g,'\n'),file);
 comparison.push({file,sha256:crypto.createHash('sha256').update(actual).digest('hex')});
}
const result={seed:333972665,runId:ev[0].runId,unchangedActions:115,actions:trace.length,entryHp:54,winHp:g.s.hp,turn:6,mode:g.s.mode,sourceComparison:comparison};
fs.writeFileSync(new URL('verification.json',root),JSON.stringify(result,null,2));fs.writeFileSync(new URL('winning-line.json',root),JSON.stringify({trace:record,final:g.s}));console.log(JSON.stringify(result,null,2));
